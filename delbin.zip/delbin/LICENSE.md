# License Agreement

Upon purchasing and/or using web templates listed on HTMLWOW website and on other template markets, you agree to this license. The terms are very simple. If you have any questions regarding your usage permissions of any template that you buy, please feel free to email me at: CreatorX64@gmail.com

## Upon purchase, you're allowed to:

- Use the templates one time if you purchased Basic License.
- Use the templates unlimited times if you purchased Premium License.
- Use the templates for any personal and/or commercial project.
- Edit/remix the templates in any shape or form to fit it for your brand/project.
- Give no attribution whatsoever to the creator of the template and/or to HTMLWOW.

## You're not allowed to:

- Redistribute/resell the templates in any free or paid forms, in any platform, even after purchasing the templates.
- Claim authorship of a template in it's recognizable/base form without any modifications.
- Use any of the templates for personal and/or commercial purposes without first purchasing them.
